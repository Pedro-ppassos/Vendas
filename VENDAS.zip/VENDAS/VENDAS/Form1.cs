﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VENDAS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Calcular_Click(object sender, EventArgs e)
        {
            // Variaveis    
            double totalCompra, desconto = 0, totalapagar;
            string nomeproduto = txt_nomeproduto.Text;
            int quantidade = int.Parse(txt_quantidade.Text);
            double precounitario = double.Parse(Txt_preço_unico.Text);




            //Procedimento 

            totalCompra = quantidade * precounitario;

            if (quantidade > 0 && quantidade <= 5)
            {
                desconto = totalCompra * 2 / 100;

            }

            else if ( quantidade >= 10)
            {
                desconto = totalCompra * 3 / 100;

            }

            else
            {
                desconto = totalCompra * 5 / 100;

            }


            // IMPRIMIR 

            totalapagar = totalCompra - desconto;
            txt_Valor_compra.Text = totalCompra.ToString("C");
            Txt_Desconto.Text = desconto.ToString("C");
            Lbl_0.Text = totalapagar.ToString("C");
         

























        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {

            txt_nomeproduto.Text = "";
            txt_quantidade.Text = "";
            Txt_preço_unico.Text = "";
            Txt_Desconto.Text = "";
            txt_Valor_compra.Text = "";
            Lbl_0.Text = "";






        }
    }
}
