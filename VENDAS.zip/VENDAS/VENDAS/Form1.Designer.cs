﻿
namespace VENDAS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.lbl_Quantidade = new System.Windows.Forms.Label();
            this.lbl_preço = new System.Windows.Forms.Label();
            this.txt_nomeproduto = new System.Windows.Forms.TextBox();
            this.txt_quantidade = new System.Windows.Forms.TextBox();
            this.Txt_preço_unico = new System.Windows.Forms.TextBox();
            this.txt_Valor_compra = new System.Windows.Forms.TextBox();
            this.Txt_Desconto = new System.Windows.Forms.TextBox();
            this.lbl_valor = new System.Windows.Forms.Label();
            this.lbl_desconto = new System.Windows.Forms.Label();
            this.btn_Calcular = new System.Windows.Forms.Button();
            this.lbl_valor_total = new System.Windows.Forms.Label();
            this.Lbl_0 = new System.Windows.Forms.Label();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Location = new System.Drawing.Point(30, 34);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(96, 13);
            this.lbl_Nome.TabIndex = 0;
            this.lbl_Nome.Text = "Nome do Produto: ";
            // 
            // lbl_Quantidade
            // 
            this.lbl_Quantidade.AutoSize = true;
            this.lbl_Quantidade.Location = new System.Drawing.Point(30, 71);
            this.lbl_Quantidade.Name = "lbl_Quantidade";
            this.lbl_Quantidade.Size = new System.Drawing.Size(62, 13);
            this.lbl_Quantidade.TabIndex = 2;
            this.lbl_Quantidade.Text = "Quantidade";
            // 
            // lbl_preço
            // 
            this.lbl_preço.AutoSize = true;
            this.lbl_preço.Location = new System.Drawing.Point(30, 108);
            this.lbl_preço.Name = "lbl_preço";
            this.lbl_preço.Size = new System.Drawing.Size(66, 13);
            this.lbl_preço.TabIndex = 3;
            this.lbl_preço.Text = "Preço Único";
            // 
            // txt_nomeproduto
            // 
            this.txt_nomeproduto.Location = new System.Drawing.Point(161, 26);
            this.txt_nomeproduto.Name = "txt_nomeproduto";
            this.txt_nomeproduto.Size = new System.Drawing.Size(249, 20);
            this.txt_nomeproduto.TabIndex = 4;
            // 
            // txt_quantidade
            // 
            this.txt_quantidade.Location = new System.Drawing.Point(161, 64);
            this.txt_quantidade.Name = "txt_quantidade";
            this.txt_quantidade.Size = new System.Drawing.Size(249, 20);
            this.txt_quantidade.TabIndex = 5;
            // 
            // Txt_preço_unico
            // 
            this.Txt_preço_unico.Location = new System.Drawing.Point(161, 105);
            this.Txt_preço_unico.Name = "Txt_preço_unico";
            this.Txt_preço_unico.Size = new System.Drawing.Size(249, 20);
            this.Txt_preço_unico.TabIndex = 6;
            // 
            // txt_Valor_compra
            // 
            this.txt_Valor_compra.Enabled = false;
            this.txt_Valor_compra.Location = new System.Drawing.Point(161, 212);
            this.txt_Valor_compra.Name = "txt_Valor_compra";
            this.txt_Valor_compra.Size = new System.Drawing.Size(249, 20);
            this.txt_Valor_compra.TabIndex = 7;
            // 
            // Txt_Desconto
            // 
            this.Txt_Desconto.Enabled = false;
            this.Txt_Desconto.Location = new System.Drawing.Point(161, 249);
            this.Txt_Desconto.Name = "Txt_Desconto";
            this.Txt_Desconto.Size = new System.Drawing.Size(249, 20);
            this.Txt_Desconto.TabIndex = 8;
            // 
            // lbl_valor
            // 
            this.lbl_valor.AutoSize = true;
            this.lbl_valor.Location = new System.Drawing.Point(30, 212);
            this.lbl_valor.Name = "lbl_valor";
            this.lbl_valor.Size = new System.Drawing.Size(85, 13);
            this.lbl_valor.TabIndex = 9;
            this.lbl_valor.Text = "Valor de Compra";
            this.lbl_valor.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_desconto
            // 
            this.lbl_desconto.AutoSize = true;
            this.lbl_desconto.Location = new System.Drawing.Point(30, 256);
            this.lbl_desconto.Name = "lbl_desconto";
            this.lbl_desconto.Size = new System.Drawing.Size(56, 13);
            this.lbl_desconto.TabIndex = 10;
            this.lbl_desconto.Text = "Desconto ";
            // 
            // btn_Calcular
            // 
            this.btn_Calcular.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btn_Calcular.Location = new System.Drawing.Point(29, 147);
            this.btn_Calcular.Name = "btn_Calcular";
            this.btn_Calcular.Size = new System.Drawing.Size(381, 34);
            this.btn_Calcular.TabIndex = 11;
            this.btn_Calcular.Text = "Calcular";
            this.btn_Calcular.UseVisualStyleBackColor = false;
            this.btn_Calcular.Click += new System.EventHandler(this.btn_Calcular_Click);
            // 
            // lbl_valor_total
            // 
            this.lbl_valor_total.AutoSize = true;
            this.lbl_valor_total.Location = new System.Drawing.Point(30, 320);
            this.lbl_valor_total.Name = "lbl_valor_total";
            this.lbl_valor_total.Size = new System.Drawing.Size(71, 13);
            this.lbl_valor_total.TabIndex = 12;
            this.lbl_valor_total.Text = "Valor a Pagar";
            // 
            // Lbl_0
            // 
            this.Lbl_0.AutoSize = true;
            this.Lbl_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_0.Location = new System.Drawing.Point(166, 308);
            this.Lbl_0.Name = "Lbl_0";
            this.Lbl_0.Size = new System.Drawing.Size(24, 25);
            this.Lbl_0.TabIndex = 13;
            this.Lbl_0.Text = "0";
            // 
            // btn_limpar
            // 
            this.btn_limpar.Location = new System.Drawing.Point(304, 315);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(106, 23);
            this.btn_limpar.TabIndex = 14;
            this.btn_limpar.Text = "limpar";
            this.btn_limpar.UseVisualStyleBackColor = true;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(471, 382);
            this.Controls.Add(this.btn_limpar);
            this.Controls.Add(this.Lbl_0);
            this.Controls.Add(this.lbl_valor_total);
            this.Controls.Add(this.btn_Calcular);
            this.Controls.Add(this.lbl_desconto);
            this.Controls.Add(this.lbl_valor);
            this.Controls.Add(this.Txt_Desconto);
            this.Controls.Add(this.txt_Valor_compra);
            this.Controls.Add(this.Txt_preço_unico);
            this.Controls.Add(this.txt_quantidade);
            this.Controls.Add(this.txt_nomeproduto);
            this.Controls.Add(this.lbl_preço);
            this.Controls.Add(this.lbl_Quantidade);
            this.Controls.Add(this.lbl_Nome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.Label lbl_Quantidade;
        private System.Windows.Forms.Label lbl_preço;
        private System.Windows.Forms.TextBox txt_nomeproduto;
        private System.Windows.Forms.TextBox txt_quantidade;
        private System.Windows.Forms.TextBox Txt_preço_unico;
        private System.Windows.Forms.TextBox txt_Valor_compra;
        private System.Windows.Forms.TextBox Txt_Desconto;
        private System.Windows.Forms.Label lbl_valor;
        private System.Windows.Forms.Label lbl_desconto;
        private System.Windows.Forms.Button btn_Calcular;
        private System.Windows.Forms.Label lbl_valor_total;
        private System.Windows.Forms.Label Lbl_0;
        private System.Windows.Forms.Button btn_limpar;
    }
}

